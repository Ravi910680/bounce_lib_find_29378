#!/bin/bash

TARGET=./Maildir/new/
PROCESSED=./processed/

inotifywait -m -e create -e moved_to --format "%f" $TARGET \
        | while read FILENAME
                do
                        echo Detected $FILENAME, moving and zipping
                        python3 ./python_for_bounce/handler.py $FILENAME

                       
                done

<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';



function select_query($conn,$sel_query){


        $ret_arr=array();

$result = $conn->query($sel_query);

if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {


    array_push($ret_arr,$row);
  }
}

return $ret_arr;

}

$servername = "database-2.ctrrqd240l6m.us-east-2.rds.amazonaws.com";
$username = "admin";
$password = "Ravi91068";
$dbname = "bounce";

$conn_of_bounce_list = mysqli_connect($servername, $username, $password,$dbname);



//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);


$sel_query="select * from `bounce_table` where flag='0' limit 10";
foreach(select_query($conn_of_bounce_list,$sel_query) as $value){
	$id=$value['id'];

	  $email=$value['email'];

	if(filter_var($email, FILTER_VALIDATE_EMAIL)==FALSE){

 $update_query="update `bounce_table` set flag='4' where id='$id'";

$conn_of_bounce_list->query($update_query);
	}else{

	$update_query="update `bounce_table` set flag='1' where id='$id'";

$conn_of_bounce_list->query($update_query);	



echo $id;
try {
    //Server settings

    $mail->isSendmail();
//Enable SMTP debugging
//SMTP::DEBUG_OFF = off (for production use)
//SMTP::DEBUG_CLIENT = client messages
//SMTP::DEBUG_SERVER = client and server messages
$mail->SMTPDebug = SMTP::DEBUG_SERVER;

//$mail->setFrom($frm_mail, $frm_name);
//Set this to true if SMTP host requires authentication to send email

$mail->CharSet = 'UTF-8';

$mail->Sender=$id.'@builtup.tech';
    //Recipients
    $mail->setFrom($id.'@builtup.tech', '500apps');
    $mail->addAddress($email, 'Joe User');     //Add a recipient

    $mail->addReplyTo('info@example.com', 'Information');

    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject = 'Why AI is not good';
    $mail->Body    = 'sen test emailfrom php';
    $mail->AltBody = 'Why AI is not good';

//    $mail->send();
    echo 'Message has been sent';










$msg = "First line of text\nSecond line of text";

// use wordwrap() if lines are longer than 70 characters
$msg = wordwrap($msg,70);
$headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <'.$id.'@builtup.tech>' . "\r\n";
//$headers .= 'Cc: myboss@example.com' . "\r\n";


// send email

mail($email,"My subject",$msg,$headers,'-f '.$id.'@builtup.tech');






//sleep(3);
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}


	}
}
